Kajun Peps Website

Contents:
- index.html
- style.css
- script.js

Place logo.jpeg in the same folder before uploading to GitHub Pages.

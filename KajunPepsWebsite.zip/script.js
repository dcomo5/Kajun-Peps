// Kajun Peps Website
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", function(e) {
      const target = document.querySelector(this.getAttribute("href"));
      if (!target) return;
      e.preventDefault();
      target.scrollIntoView({behavior:"smooth", block:"start"});
    });
  });

  const search = document.getElementById("searchInput");
  if (search) {
    search.addEventListener("input", function() {
      const value = this.value.toLowerCase();
      document.querySelectorAll(".product-card").forEach(card => {
        const text = card.textContent.toLowerCase();
        card.style.display = text.includes(value) ? "" : "none";
      });
    });
  }

  const observer = new IntersectionObserver((entries)=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        entry.target.style.opacity="1";
        entry.target.style.transform="translateY(0)";
      }
    });
  }, {threshold:0.15});

  document.querySelectorAll("section, .product-card").forEach(el=>{
    el.style.opacity="0";
    el.style.transform="translateY(40px)";
    el.style.transition="all .7s ease";
    observer.observe(el);
  });

  const header = document.querySelector("header");
  window.addEventListener("scroll", ()=>{
    if(!header) return;
    header.style.background = window.scrollY > 40
      ? "rgba(0,0,0,.80)"
      : "rgba(0,0,0,.35)";
  });

  console.log("Kajun Peps website loaded.");
});
